package com.vanta.panel

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(9,10,15)) }
        val status = TextView(this).apply {
            text = "VANTA FLOATING MODE\nAllow ‘Display over other apps’ to show the movable panel above Free Fire India."
            setTextColor(Color.WHITE); textSize = 16f; setPadding(20, 18, 20, 18)
        }
        val permission = Button(this).apply { text = "ENABLE FLOATING PANEL"; setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else startFloating()
        } }
        val launch = Button(this).apply { text = "OPEN FREE FIRE INDIA"; setOnClickListener { launchFreeFire() } }
        val web = WebView(this).apply { settings.javaScriptEnabled = true; webViewClient = WebViewClient(); loadUrl("file:///android_asset/index.html") }
        root.addView(status); root.addView(permission); root.addView(launch)
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }
    override fun onResume() { super.onResume(); if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) { /* permission granted; user can tap enable */ } }
    private fun startFloating() { startService(Intent(this, FloatingService::class.java)) }
    private fun launchFreeFire() {
        val packages = listOf("com.dts.freefireth", "com.dts.freefiremax")
        for (pkg in packages) {
            val launchIntent = packageManager.getLaunchIntentForPackage(pkg)
            if (launchIntent != null) { startActivity(launchIntent); return }
        }
        android.widget.Toast.makeText(this, "Free Fire / Free Fire MAX was not found. Install the official game first.", android.widget.Toast.LENGTH_LONG).show()
    }
}
