package com.vanta.panel

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Color
import android.graphics.Typeface
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int { showBubble(); return START_STICKY }
    private fun layoutType(): Int = if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
    private fun showBubble() {
        if (bubble != null) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = TextView(this).apply {
            text = "V"; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(220, 20, 55)); setTypeface(null, Typeface.BOLD)
            setOnClickListener { if (panel == null) showPanel() else hidePanel() }
        }
        val p = WindowManager.LayoutParams(58, 58, layoutType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 12; y = 180 }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; true }
                MotionEvent.ACTION_MOVE -> { p.x = ox + (e.rawX - sx).toInt(); p.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(b, p); true }
                MotionEvent.ACTION_UP -> { if (kotlin.math.abs(e.rawX-sx) < 8 && kotlin.math.abs(e.rawY-sy) < 8) { if (panel == null) showPanel() else hidePanel() }; true }
                else -> false
            }
        }
        wm.addView(b, p); bubble = b; params = p
    }
    private fun showPanel() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18,14,18,14); setBackgroundColor(Color.rgb(18,19,27)) }
        fun action(label: String, run: () -> Unit) { val t = TextView(this).apply { text = label; textSize = 15f; setTextColor(Color.WHITE); setPadding(12,14,12,14); setOnClickListener { run() } }; box.addView(t) }
        val title = TextView(this).apply { text = "VANTA // QUICK PANEL"; textSize = 17f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(255,65,90)); setPadding(12,10,12,10) }
        box.addView(title)
        action("OPEN FREE FIRE INDIA") { launchGame() }
        action("OPEN FULL VANTA PANEL") { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        action("CLOSE QUICK PANEL") { hidePanel() }
        action("EXIT FLOATING MODE") { stopSelf() }
        val pp = WindowManager.LayoutParams(230, WindowManager.LayoutParams.WRAP_CONTENT, layoutType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 78; y = 180 }
        wm.addView(box, pp); panel = box
    }
    private fun hidePanel() { panel?.let { wm.removeView(it) }; panel = null }
    private fun launchGame() {
        val candidates = listOf("com.dts.freefireth", "com.dts.freefiremax")
        for (pkg in candidates) { val i = packageManager.getLaunchIntentForPackage(pkg); if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); return } }
        Toast.makeText(this, "Free Fire was not found on this device.", Toast.LENGTH_LONG).show()
    }
    override fun onDestroy() { hidePanel(); bubble?.let { wm.removeView(it) }; bubble = null; super.onDestroy() }
}
