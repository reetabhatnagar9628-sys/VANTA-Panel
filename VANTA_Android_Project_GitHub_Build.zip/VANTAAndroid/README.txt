VANTA Android companion app source

WHAT IT DOES
- Shows the existing VANTA HTML dashboard inside an Android app.
- Adds a movable floating VANTA bubble above other apps (Android overlay permission required).
- Floating quick panel can launch Free Fire / Free Fire MAX if installed, open VANTA, or close the overlay.
- No game files are modified. Aim/fly/teleport/anti-ban items remain visual demos only.

BUILD
1. Open this folder in Android Studio (current stable version).
2. Let Gradle sync and install the Android SDK Platform 35 if prompted.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated APK on your Android device.
5. Open VANTA, tap ENABLE FLOATING PANEL, and allow Display over other apps.
6. Tap the V bubble to open the quick panel. Drag it to move it.

NOTES
- This is Android Studio source, not a prebuilt APK.
- Launching the game checks package IDs com.dts.freefireth and com.dts.freefiremax. If your Free Fire India build uses a different package ID, the launch button may report that it cannot find the game.
- Android may restrict overlays on some secure screens. The floating panel is a normal overlay, not an in-game mod or cheat.
